const themeButton = document.getElementById('themeButton');
themeButton.addEventListener('click', () => {
  document.body.classList.toggle('dark-mode');
});
